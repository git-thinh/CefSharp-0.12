﻿using System.Reflection;
using System.Runtime.CompilerServices;
using System.Runtime.InteropServices;

[assembly: AssemblyTitle("CefSharp.Example")]
[assembly: AssemblyCompany("Anthony Taranto")]
[assembly: AssemblyProduct("CefSharp.Example")]
[assembly: AssemblyCopyright("Copyright © 2012")]

[assembly: AssemblyVersion("0.12.*")]
[assembly: ComVisible(false)]
